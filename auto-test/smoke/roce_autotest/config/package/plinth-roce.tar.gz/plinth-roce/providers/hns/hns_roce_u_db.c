/*
 * Copyright (c) 2017 Hisilicon Limited.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "hns_roce_u.h"
#include "hns_roce_u_db.h"

static struct hns_roce_db_page *hns_roce_add_db_page(
						struct hns_roce_context *ctx,
						enum hns_roce_db_type type)
{
	struct hns_roce_db_page *page;
	uint32_t bitmap_num;
	uint32_t page_size;
	int i;

	/* alloc db page */
	page_size = (uint32_t)to_hr_dev(ctx->ibv_ctx.context.device)->page_size;
	page = (struct hns_roce_db_page *)calloc(1, sizeof(*page));
	if (!page)
		goto err_page;

	/* allocate bitmap space for sw db */
	page->num_db = page_size / db_size[type];
	page->use_cnt = 0;
	bitmap_num = (uint32_t)align(page->num_db,
				     BIT_CNT_PER_BYTE * sizeof(uint64_t));

	page->bitmap = calloc(1, bitmap_num / BIT_CNT_PER_BYTE);
	if (!page->bitmap)
		goto err_map;

	/* bitmap_num indicate the mount of u64 */
	bitmap_num = bitmap_num / (BIT_CNT_PER_BYTE * sizeof(uint64_t));

	if (hns_roce_alloc_buf(&(page->buf), page_size, (int)page_size))
		goto err;

	/* init the sw db bitmap */
	for (i = 0; i < bitmap_num; ++i)
		page->bitmap[i] = ~(0UL);

	/* add the set ctx->db_list */
	page->prev = NULL;
	page->next = ctx->db_list[type];
	ctx->db_list[type] = page;
	if (page->next)
		page->next->prev = page;

	return page;
err:
	free(page->bitmap);
	page->bitmap = NULL;

err_map:
	free(page);
	page = NULL;

err_page:
	return NULL;
}

static void hns_roce_clear_db_page(struct hns_roce_db_page *page)
{
	if (!page) {
		fprintf(stderr, "error clear: db page is NULL!\n");
		return;
	}

	if (page->bitmap) {
		free(page->bitmap);
		page->bitmap = NULL;
	}

	hns_roce_free_buf(&(page->buf));
}

void *hns_roce_alloc_db(struct hns_roce_context *ctx,
			enum hns_roce_db_type type)
{
	struct hns_roce_db_page *page;
	void *db = NULL;
	uint32_t bit_num;
	uint32_t i;

	pthread_mutex_lock((pthread_mutex_t *)&ctx->db_list_mutex);

	for (page = ctx->db_list[type]; page != NULL; page = page->next)
		if (page->use_cnt < page->num_db)
			goto found;

	page = hns_roce_add_db_page(ctx, type);
	if (!page)
		goto out;

found:
	++page->use_cnt;
	/* if the bitmap is allocated, the bitmap[i] is set zero */
	for (i = 0; page->bitmap[i] == 0; ++i)
		;

	bit_num = (uint32_t)ffsl(page->bitmap[i]);
	page->bitmap[i] &= ~(1ULL << (bit_num - 1));

	db = (void *)((uint8_t *)(page->buf.buf) +
			(size_t)((i * sizeof(uint64_t) * BIT_CNT_PER_BYTE +
			(bit_num - 1)) * db_size[type]));

out:
	pthread_mutex_unlock((pthread_mutex_t *)&ctx->db_list_mutex);

	return db;
}

void hns_roce_free_db(struct hns_roce_context *ctx, unsigned int *db,
		      enum hns_roce_db_type type)
{
	struct hns_roce_db_page *page;
	uint32_t bit_num;
	uint32_t page_size;

	pthread_mutex_lock((pthread_mutex_t *)&ctx->db_list_mutex);

	page_size = (uint32_t)to_hr_dev(ctx->ibv_ctx.context.device)->page_size;
	for (page = ctx->db_list[type]; page != NULL; page = page->next)
		if (((uintptr_t)db & (~((uintptr_t)page_size - 1))) ==
						(uintptr_t)(page->buf.buf))
			goto found;

	fprintf(stderr, "db page can't be found!\n");
	goto out;

found:
	--page->use_cnt;
	if (!page->use_cnt) {
		if (page->prev)
			page->prev->next = page->next;
		else
			ctx->db_list[type] = page->next;

		if (page->next)
			page->next->prev = page->prev;

		hns_roce_clear_db_page(page);
		free(page);
		page = NULL;

		goto out;
	}

	bit_num = (uint32_t)(((uintptr_t)db - (uintptr_t)page->buf.buf) /
								db_size[type]);
	page->bitmap[bit_num / (sizeof(uint64_t) * BIT_CNT_PER_BYTE)] |=
			     ((uint64_t)1ULL) <<
			     (bit_num % (sizeof(uint64_t) * BIT_CNT_PER_BYTE));

out:
	pthread_mutex_unlock((pthread_mutex_t *)&ctx->db_list_mutex);
}
